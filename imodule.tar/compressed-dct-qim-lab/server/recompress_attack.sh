#!/bin/bash
set -euo pipefail

input="${1:-public/stego_dct_qim.mp4}"
output="${2:-public/stego_recompressed.mp4}"

ffmpeg -y -i "$input" -c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p -an "$output"
echo "recompression complete: $output"
