#!/usr/bin/env python3
import hashlib
import json
import sys
from pathlib import Path

import cv2
import numpy as np


def seed_from_key(key_text: str) -> int:
    digest = hashlib.sha256(key_text.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def selected_positions(frame_count: int, height: int, width: int, bit_count: int, key_text: str) -> np.ndarray:
    block_rows = height // 8
    block_cols = width // 8
    capacity = frame_count * block_rows * block_cols
    if bit_count > capacity:
        raise SystemExit(f"payload too large for cover video: bits={bit_count} capacity={capacity}")

    rng = np.random.default_rng(seed_from_key(key_text))
    all_positions = np.arange(capacity)
    rng.shuffle(all_positions)
    return all_positions[:bit_count]


def embed_bit(coefficient: float, bit: int, delta: int) -> float:
    q = int(np.round(coefficient / delta))
    #TODO Hoan thien logic QIM
    

def main() -> None:
    in_video = Path(sys.argv[1] if len(sys.argv) > 1 else "cover.mp4")
    bits_path = Path(sys.argv[2] if len(sys.argv) > 2 else "payload_bits.txt")
    key_path = Path(sys.argv[3] if len(sys.argv) > 3 else "stego_key.txt")
    out_video = Path(sys.argv[4] if len(sys.argv) > 4 else "public/stego_dct_qim.mp4")
    meta_path = Path(sys.argv[5] if len(sys.argv) > 5 else "payload_meta.json")

    bits = bits_path.read_text(encoding="ascii").strip()
    if not bits or any(bit not in "01" for bit in bits):
        raise SystemExit("payload bit file must contain only 0 and 1")
    key_text = key_path.read_text(encoding="utf-8").strip()
    if not key_text:
        raise SystemExit("stego key is empty")
    metadata = json.loads(meta_path.read_text(encoding="ascii"))
    delta = int(metadata["delta"])
    coeff_y, coeff_x = [int(v) for v in metadata["coeff_yx"]]

    cap = cv2.VideoCapture(str(in_video))
    if not cap.isOpened():
        raise SystemExit(f"cannot open {in_video}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 24
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    positions = selected_positions(frame_count, height, width, len(bits), key_text)
    position_to_bit = {int(pos): int(bit) for pos, bit in zip(positions, bits)}

    out_video.parent.mkdir(parents=True, exist_ok=True)
    writer = cv2.VideoWriter(str(out_video), cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height))
    if not writer.isOpened():
        raise SystemExit(f"cannot create {out_video}")

    block_rows = height // 8
    block_cols = width // 8
    blocks_per_frame = block_rows * block_cols
    embedded = 0
    frame_index = 0

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        y_channel = ycrcb[:, :, 0].astype(np.float32)
        frame_base = frame_index * blocks_per_frame

        for block_index in range(blocks_per_frame):
            global_pos = frame_base + block_index
            bit = position_to_bit.get(global_pos)
            if bit is None:
                continue

            row = (block_index // block_cols) * 8
            col = (block_index % block_cols) * 8
            block = y_channel[row : row + 8, col : col + 8]
            dct_block = cv2.dct(block - 128.0)
            dct_block[coeff_y, coeff_x] = embed_bit(float(dct_block[coeff_y, coeff_x]), bit, delta)
            y_channel[row : row + 8, col : col + 8] = cv2.idct(dct_block) + 128.0
            embedded += 1

        ycrcb[:, :, 0] = np.clip(y_channel, 0, 255).astype(np.uint8)
        writer.write(cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR))
        frame_index += 1

    cap.release()
    writer.release()

    if embedded != len(bits):
        raise SystemExit(f"embedded {embedded} bits but expected {len(bits)}")

    public_meta = out_video.parent / meta_path.name
    public_key_hint = out_video.parent / "key_hint.txt"
    public_meta.write_text(json.dumps(metadata, indent=2) + "\n", encoding="ascii")
    public_key_hint.write_text("Use the shared key file stego_key.txt on the client.\n", encoding="ascii")
    print(f"dct-qim embedded: bits={embedded} blocks={embedded} delta={delta} output={out_video}")


if __name__ == "__main__":
    main()
