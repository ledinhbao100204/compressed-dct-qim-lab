#!/usr/bin/env python3
import json
import struct
import sys
import zlib
from pathlib import Path


MAGIC = b"DCTQIM1"
REPEAT = 15
DELTA = 160
COEFF = [1, 2]


def bits_from_bytes(data: bytes) -> str:
    return "".join(f"{byte:08b}" for byte in data)


def main() -> None:
    msg_path = Path(sys.argv[1] if len(sys.argv) > 1 else "secret_message.txt")
    bits_path = Path(sys.argv[2] if len(sys.argv) > 2 else "payload_bits.txt")
    meta_path = Path(sys.argv[3] if len(sys.argv) > 3 else "payload_meta.json")

    message = msg_path.read_bytes().rstrip(b"\r\n")
    if not message:
        raise SystemExit("message is empty")
    if len(message) > 65535:
        raise SystemExit("message too long: maximum is 65535 bytes")

    crc = zlib.crc32(message) & 0xFFFFFFFF
    packet = MAGIC + struct.pack(">H", len(message)) + message + struct.pack(">I", crc)
    raw_bits = bits_from_bytes(packet)
    repeated_bits = "".join(bit * REPEAT for bit in raw_bits)

    bits_path.write_text(repeated_bits + "\n", encoding="ascii")
    metadata = {
        "magic": MAGIC.decode("ascii"),
        "message_length": len(message),
        "crc32": f"{crc:08x}",
        "repeat": REPEAT,
        "raw_bit_count": len(raw_bits),
        "repeated_bit_count": len(repeated_bits),
        "delta": DELTA,
        "coeff_yx": COEFF,
        "block_size": 8,
        "channel": "Y",
        "method": "DCT-QIM parity on mid-frequency coefficient",
    }
    meta_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="ascii")

    print(
        "payload prepared: "
        f"length={len(message)} crc32={crc:08x} raw_bits={len(raw_bits)} repeated_bits={len(repeated_bits)}"
    )


if __name__ == "__main__":
    main()
