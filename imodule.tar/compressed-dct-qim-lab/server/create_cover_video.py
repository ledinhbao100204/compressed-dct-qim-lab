#!/usr/bin/env python3
from pathlib import Path

import cv2
import numpy as np


WIDTH = 320
HEIGHT = 240
FPS = 24
FRAMES = 160


def make_frame(index: int, rng: np.random.Generator) -> np.ndarray:
    x = np.linspace(0, 255, WIDTH, dtype=np.float32)
    y = np.linspace(0, 255, HEIGHT, dtype=np.float32)[:, None]
    wave = 35 * np.sin((x[None, :] + index * 4) / 17.0)
    texture = rng.normal(0, 18, (HEIGHT, WIDTH)).astype(np.float32)

    base = (0.45 * x[None, :] + 0.35 * y + wave + texture + 70) % 256
    frame = np.zeros((HEIGHT, WIDTH, 3), dtype=np.uint8)
    frame[:, :, 0] = np.clip(base, 0, 255).astype(np.uint8)
    frame[:, :, 1] = np.clip(255 - base * 0.55 + index, 0, 255).astype(np.uint8)
    frame[:, :, 2] = np.clip(base * 0.7 + 60, 0, 255).astype(np.uint8)

    cx = 40 + (index * 3) % (WIDTH - 80)
    cy = 55 + int(35 * np.sin(index / 9.0))
    cv2.circle(frame, (cx, cy), 24, (35, 220, 180), -1)
    cv2.rectangle(
        frame,
        (WIDTH - 95, 25 + (index * 2) % 90),
        (WIDTH - 35, 85 + (index * 2) % 90),
        (210, 65, 85),
        -1,
    )
    cv2.putText(frame, "DCT-QIM", (18, HEIGHT - 24), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (245, 245, 245), 2)
    return frame


def main() -> None:
    out_path = Path("cover.mp4")
    rng = np.random.default_rng(20260514)
    writer = cv2.VideoWriter(str(out_path), cv2.VideoWriter_fourcc(*"mp4v"), FPS, (WIDTH, HEIGHT))
    if not writer.isOpened():
        raise SystemExit("cannot create cover video")

    for i in range(FRAMES):
        writer.write(make_frame(i, rng))
    writer.release()

    print(f"cover video created: {out_path} frames={FRAMES} size={WIDTH}x{HEIGHT} fps={FPS}")


if __name__ == "__main__":
    main()
