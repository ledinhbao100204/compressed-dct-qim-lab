# Compressed Domain DCT-QIM Steganography Lab

## Muc tieu

Sinh vien thuc hanh giau tin trong mien bien doi cua video thay vi sua byte truc tiep. Bai lab dung DCT tren kenh do sang Y, nhung bit bang QIM vao he so thap-trung tan cua cac block 8x8, sau do kiem tra kha nang khoi phuc thong diep khi video bi nen lai bang H.264.

## Mo hinh lab

Lab gom hai container:

- `server`: tao cover video, tao payload co metadata/CRC, nhung payload bang DCT-QIM, tao ban video bi nen lai, va chia se file qua HTTP.
- `client`: tai video va metadata, trich xuat payload bang khoa chia se, kiem CRC, va so sanh thong diep.

Container `client` truy cap `server` qua hostname `server` trong mang noi bo `labnet`.

## Yeu cau hoan thanh

1. Tren `server`, mo file `embed_dct_qim.py` va sua ham `embed_bit(coefficient, bit, delta)`.

   Ham nay dang de `TODO` va se lam chuong trinh dung voi `NotImplementedError`. Day la phan code duy nhat sinh vien bat buoc sua. Muc tieu la hoan thien logic QIM parity theo quy tac:

   - luong tu hoa he so DCT bang `round(coefficient / delta)`;
   - neu chi so luong tu hoa chua co parity bang bit can nhung, chon chi so gan nhat co parity dung;
   - tra ve he so moi bang `quantization_index * delta`.

   Extractor da dung quy tac `round(coefficient / delta) % 2` de doc bit, vi vay ham nhung phai tuong thich voi quy tac nay.

   Goi y hoan thien code:

   ```python
   q = int(np.round(coefficient / delta))
   if q % 2 != bit:
       up = q + 1
       down = q - 1
       if abs(up * delta - coefficient) <= abs(down * delta - coefficient):
           q = up
       else:
           q = down
   return float(q * delta)
   ```

   Sau khi sua, khong con dong `raise NotImplementedError(...)` trong ham `embed_bit()`.

2. Tren `server`, tao video goc:

   ```bash
   ./create_cover_video.py
   ```

3. Tren `server`, tao bitstream co magic, length, CRC va ma lap 15 lan:

   ```bash
   ./prepare_payload.py secret_message.txt payload_bits.txt payload_meta.json
   ```

4. Tren `server`, nhung bitstream vao he so DCT bang QIM:

   ```bash
   ./embed_dct_qim.py cover.mp4 payload_bits.txt stego_key.txt public/stego_dct_qim.mp4 payload_meta.json
   ```

5. Tren `server`, nen lai video bang H.264 de mo phong tac dong cua nen mat thong tin:

   ```bash
   ./recompress_attack.sh public/stego_dct_qim.mp4 public/stego_recompressed.mp4
   ```

6. Tren `server`, phuc vu thu muc `public` qua HTTP:

   ```bash
   cd public
   python3 -m http.server 8000
   ```

7. Tren `client`, tai video va metadata:

   ```bash
   wget http://server:8000/stego_recompressed.mp4
   wget http://server:8000/payload_meta.json
   ```

8. Tren `client`, trich xuat thong diep bang metadata va khoa chia se:

   ```bash
   ./extract_dct_qim.py stego_recompressed.mp4 payload_meta.json stego_key.txt extracted_message.txt
   ```

9. Tren `client`, so sanh thong diep:

   ```bash
   ./compare_file.py expected_message.txt extracted_message.txt
   ```

## Cau hoi bao cao

1. Vi sao bai lab chon he so DCT trung tan thay vi DC hoac tan so rat cao?
2. Tham so `delta` trong QIM anh huong the nao den chat luong video va do ben khi nen lai?
3. Vi sao payload can co magic, length, CRC va ma lap 15 lan?
4. So sanh cach nhung LSB tren byte file MP4 voi cach nhung DCT-QIM trong mien bien doi.
5. Neu doi CRF cua H.264 tu 23 len 32, ban du doan ty le loi bit thay doi the nao?
6. Neu ham `embed_bit()` chon sai parity, extractor se bao loi nao va vi sao?

## Cham diem tu dong

He thong cham diem kiem tra cac moc:

- `server:create_cover_video.py.stdout` co chuoi `cover video created`.
- `server:prepare_payload.py.stdout` co chuoi `payload prepared` va `crc32=`.
- `server:embed_dct_qim.py.stdout` co chuoi `dct-qim embedded`; moc nay chi dat sau khi sinh vien sua dung ham `embed_bit()`.
- `server:recompress_attack.sh.stdout` co chuoi `recompression complete`.
- `server:.bash_history` co lenh `python3 -m http.server 8000`.
- `client:wget.stdout` co chuoi `200 OK`.
- `client:extract_dct_qim.py.stdout` co chuoi `crc ok`.
- `client:compare_file.py.stdout` hoac marker pregrade co chuoi `messages match`.

## Goi y

Neu extractor bao `magic mismatch` hoac `crc mismatch`, hay kiem tra lai video, metadata, khoa `stego_key.txt`, va viec tai dung file `stego_recompressed.mp4`.

Neu buoc nhung dung voi loi `NotImplementedError`, nghia la ham `embed_bit()` van chua duoc hoan thien hoac chua xoa dong `raise`.
