#!/usr/bin/env python3
import hashlib
import json
import struct
import sys
import zlib
from pathlib import Path

import cv2
import numpy as np


MAGIC = b"DCTQIM1"


def seed_from_key(key_text: str) -> int:
    digest = hashlib.sha256(key_text.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def selected_positions(frame_count: int, height: int, width: int, bit_count: int, key_text: str) -> np.ndarray:
    block_rows = height // 8
    block_cols = width // 8
    capacity = frame_count * block_rows * block_cols
    if bit_count > capacity:
        raise SystemExit(f"requested bits exceed video capacity: bits={bit_count} capacity={capacity}")

    rng = np.random.default_rng(seed_from_key(key_text))
    all_positions = np.arange(capacity)
    rng.shuffle(all_positions)
    return all_positions[:bit_count]


def detect_bit(coefficient: float, delta: int) -> str:
    q = int(np.round(coefficient / delta))
    return str(q % 2)


def majority_vote(bits: str, repeat: int) -> str:
    voted = []
    for i in range(0, len(bits), repeat):
        group = bits[i : i + repeat]
        if len(group) != repeat:
            break
        voted.append("1" if group.count("1") >= ((repeat // 2) + 1) else "0")
    return "".join(voted)


def bytes_from_bits(bits: str) -> bytes:
    output = bytearray()
    for i in range(0, len(bits), 8):
        byte = bits[i : i + 8]
        if len(byte) == 8:
            output.append(int(byte, 2))
    return bytes(output)


def parse_packet(packet: bytes) -> bytes:
    if not packet.startswith(MAGIC):
        raise SystemExit("magic mismatch: wrong key, damaged video, or wrong metadata")
    offset = len(MAGIC)
    if len(packet) < offset + 2:
        raise SystemExit("packet too short")
    message_length = struct.unpack(">H", packet[offset : offset + 2])[0]
    offset += 2
    end = offset + message_length
    if len(packet) < end + 4:
        raise SystemExit("packet length mismatch")
    message = packet[offset:end]
    stored_crc = struct.unpack(">I", packet[end : end + 4])[0]
    actual_crc = zlib.crc32(message) & 0xFFFFFFFF
    if stored_crc != actual_crc:
        raise SystemExit(f"crc mismatch: expected={stored_crc:08x} actual={actual_crc:08x}")
    return message


def main() -> None:
    in_video = Path(sys.argv[1] if len(sys.argv) > 1 else "stego_recompressed.mp4")
    meta_path = Path(sys.argv[2] if len(sys.argv) > 2 else "payload_meta.json")
    key_path = Path(sys.argv[3] if len(sys.argv) > 3 else "stego_key.txt")
    out_path = Path(sys.argv[4] if len(sys.argv) > 4 else "extracted_message.txt")

    metadata = json.loads(meta_path.read_text(encoding="ascii"))
    repeated_bit_count = int(metadata["repeated_bit_count"])
    repeat = int(metadata["repeat"])
    delta = int(metadata["delta"])
    coeff_y, coeff_x = [int(v) for v in metadata["coeff_yx"]]
    key_text = key_path.read_text(encoding="utf-8").strip()

    cap = cv2.VideoCapture(str(in_video))
    if not cap.isOpened():
        raise SystemExit(f"cannot open {in_video}")
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    positions = selected_positions(frame_count, height, width, repeated_bit_count, key_text)
    positions_needed = set(int(pos) for pos in positions)

    block_rows = height // 8
    block_cols = width // 8
    blocks_per_frame = block_rows * block_cols
    detected_by_position = {}
    frame_index = 0

    while len(detected_by_position) < repeated_bit_count:
        ok, frame = cap.read()
        if not ok:
            break
        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        y_channel = ycrcb[:, :, 0].astype(np.float32)
        frame_base = frame_index * blocks_per_frame

        for block_index in range(blocks_per_frame):
            global_pos = frame_base + block_index
            if global_pos not in positions_needed:
                continue
            row = (block_index // block_cols) * 8
            col = (block_index % block_cols) * 8
            block = y_channel[row : row + 8, col : col + 8]
            dct_block = cv2.dct(block - 128.0)
            detected_by_position[global_pos] = detect_bit(float(dct_block[coeff_y, coeff_x]), delta)

        frame_index += 1

    cap.release()
    if len(detected_by_position) != repeated_bit_count:
        raise SystemExit(f"extracted {len(detected_by_position)} bits but expected {repeated_bit_count}")

    repeated_bits = "".join(detected_by_position[int(pos)] for pos in positions)
    packet_bits = majority_vote(repeated_bits, repeat)
    message = parse_packet(bytes_from_bits(packet_bits))
    out_path.write_bytes(message)
    print(f"crc ok: extracted message: {message.decode('utf-8', errors='replace')}")


if __name__ == "__main__":
    main()
