#!/bin/bash
set -e

cd /home/ubuntu
chmod +x extract_lsb.py compare_file.py 2>/dev/null || true
