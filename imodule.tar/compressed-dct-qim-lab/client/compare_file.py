#!/usr/bin/env python3
import sys
from pathlib import Path


def main() -> None:
    expected = Path(sys.argv[1] if len(sys.argv) > 1 else "expected_message.txt")
    actual = Path(sys.argv[2] if len(sys.argv) > 2 else "extracted_message.txt")

    expected_bytes = expected.read_bytes().rstrip(b"\r\n")
    actual_bytes = actual.read_bytes().rstrip(b"\r\n")
    if expected_bytes != actual_bytes:
        print("messages differ")
        print(f"expected: {expected_bytes.decode(errors='replace')}")
        print(f"actual:   {actual_bytes.decode(errors='replace')}")
        raise SystemExit(1)

    print("messages match")


if __name__ == "__main__":
    main()
