#!/bin/bash
set -e

cd /home/ubuntu
chmod +x create_cover_video.py embed_lsb.py 2>/dev/null || true
mkdir -p public
chown -R ubuntu:ubuntu /home/ubuntu/public
