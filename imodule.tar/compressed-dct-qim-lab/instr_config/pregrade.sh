#!/bin/bash
homedir=$1
destdir=$2
dbg=/tmp/compressed-dct-qim-lab-pregrade.log

cd "$homedir/$destdir" 2>/dev/null || exit 0

if [ -f extracted_message.txt ] && [ -f expected_message.txt ]; then
    if cmp -s extracted_message.txt expected_message.txt; then
        mkdir -p .local/result
        echo "messages match" > .local/result/message_compare.txt
    fi
fi

echo "pregrade complete for $destdir" >> "$dbg"
