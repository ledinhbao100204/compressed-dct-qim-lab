$ErrorActionPreference = "Stop"

$imagePrefix = "ledinhbao1002/compressed-dct-qim-lab"

docker push "$imagePrefix.server.student"
docker push "$imagePrefix.client.student"
